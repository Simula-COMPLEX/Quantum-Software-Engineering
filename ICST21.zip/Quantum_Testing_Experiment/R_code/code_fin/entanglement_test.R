


if (!require(psych)) {
  install.packages("psych")
}
if (!require(FSA)) {
  install.packages("FSA")
}
if (!require(rcompanion)) {
  install.packages("rcompanion")
}
if (!require(coin)) {
  install.packages("coin")
}
library(comprehenr)
library(psych)


# reading files
data_dir <- "D:/WXY/Experiments_final/Entanglement (3-2)/result"
output_dir <- "D:/WXY/Experiments_final/Entanglement (3-2)/analysis_new"
M <- 1:10
C <- 1:3
# M<-2:2
# C<-2:2
test_result_df = data.frame(matrix(NA, nrow = length(M)+7, ncol = length(C)))
row.names(test_result_df) <- c(to_vec(for (m in M)
  paste("M", m, sep = "")),"Avg_test_suite_size")
colnames(test_result_df) <- to_vec(for (c in C)
  paste("C", c, sep = ""))
fnames = to_vec(for (m in M)
  for (c in C)
    paste("M", m, "C", c, ".txt", sep = ""))
fpaths = to_vec(for (fname in fnames)
  file.path(data_dir, fname))
valid_fpaths = to_vec(for (fpath in fpaths)
  if (file.exists(fpath))
    fpath)

# data process
n_files = length(valid_fpaths)
sample_size = 100
total_test_suite_size = c(0, 0, 0)
total_test_suite_count = c(0, 0, 0)
total_test_cases = c(0, 0, 0)
O1 = c(0, 0, 0)
total_O1_case = c(0, 0, 0)
O3 = c(0, 0, 0)
total_O3_case = c(0, 0, 0)
Pass = c(0, 0, 0)
total_pass_case = c(0, 0, 0)
flag = 4
names(total_test_suite_size) = c("C1", "C2", "C3")
names(total_test_suite_count) = c("C1", "C2", "C3")
names(total_test_cases) = c("C1", "C2", "C3")
names(O1) = c("C1", "C2", "C3")
names(total_O1_case) = c("C1", "C2", "C3")
names(O3) = c("C1", "C2", "C3")
names(total_O3_case) = c("C1", "C2", "C3")
names(Pass) = c("C1", "C2", "C3")
names(total_pass_case) = c("C1", "C2", "C3")

for (fpath in valid_fpaths) {
  # initialization
  
  row_col_names = parse_fpath(fpath)
  row = row_col_names[1]
  col = row_col_names[2]
  print(paste("reading file", fpath))
  f = file(fpath, open = "r")
  lines = readLines(f)
  n_lines = length(lines)
  close(f)
  file_test_suite_size<-0
  file_test_suite_count<-0
  flag = 4#O1 or O3 or Pass
  # calculate each sample
  n_samples = n_lines %/% sample_size#2000/100=20
  if(n_samples == 0){
    n_samples = 1
  }
  count_df = data.frame(
    rep(0, n_samples),
    rep(0, n_samples),
    rep(0, n_samples),
    rep(0, n_samples),
    rep(0, n_samples),
    rep(0, n_samples),
    rep(0, n_samples),
    rep(0, n_samples)
  )
  colnames(count_df) <-
    c("0", "1", "2", "3", "(0,0)", "(0,3)", "(1,0)", "(1,3)")
  for (sample_i in 1:n_samples) {
    start_i = (sample_i - 1) * sample_size + 1
    end_i = start_i + sample_size - 1
    sample_lines = lines[start_i:end_i]
    if(n_samples == 1){
      sample_lines = lines
    }
    for (line in sample_lines) {
      ios = unlist(strsplit(line, ","))
      inputs = ios[c(TRUE, FALSE)]
      outputs = ios[c(FALSE, TRUE)]
      for (i in 1:length(inputs)) {
        input <- inputs[i]
        output <- outputs[i]
        if(output==1|output==2){
          flag = 1 #O1
          file_test_suite_size = file_test_suite_size+i
          break;
        }
        count_df[sample_i, output] <- count_df[sample_i, output] + 1
        combined = paste("(", input, ",", output, ")", sep = "")
        if (combined %in% colnames(count_df)) {
          count_df[sample_i, combined] <- count_df[sample_i, combined] + 1
        }
      }
      if(flag==1){
        break;
      }
      file_test_suite_count<-file_test_suite_count+1
      file_test_suite_size<-file_test_suite_size+length(inputs)
      
    }
    if(flag==1){
      break;
    }
    
  }
  
  
  if(flag == 1){
    result_str = NA
    O1[col] <- O1[col] + 1
    total_O1_case[col] <- (total_O1_case[col] + file_test_suite_size)
    print("O1:")
    print(file_test_suite_size)
    print(O1[col])
    total_test_suite_size[col]<-total_test_suite_size[col]+file_test_suite_size
    result_str_stop <- 
      paste("stop at invalid output:",file_test_suite_size)
    result_str_category <-
      paste("Category: O1")
    result_str = paste(result_str_stop,
                       result_str_category,
                       sep = "\n") 
  }
  else if(flag != 1){
    # calculate test suite size
    #total_test_suite_size[col] <-
      #(total_test_suite_size[col] + length(inputs))
    #total_test_suite_count[col] <- total_test_suite_count[col] + 1
    # calculate sum of test suite
    #total_test_cases[col] <- (total_test_cases[col] + file_test_suite_size)  
  # calculate frequency
  count_df["sum"] <-
    count_df["0"] + count_df["1"] + count_df["2"] + count_df["3"]
  count_df["freq:0"] <-
    as.numeric(unlist(count_df["0"] / count_df["sum"]))
  count_df["freq:1"] <-
    as.numeric(unlist(count_df["1"] / count_df["sum"]))
  count_df["freq:2"] <-
    as.numeric(unlist(count_df["2"] / count_df["sum"]))
  count_df["freq:3"] <-
    as.numeric(unlist(count_df["3"] / count_df["sum"]))
  
  count_df["freq:(0,0)"] <-
    as.numeric(unlist(count_df["(0,0)"] / (count_df["(0,0)"] + count_df["(0,3)"])))
  count_df["freq:(0,3)"] <-
    as.numeric(unlist(count_df["(0,3)"] / (count_df["(0,0)"] + count_df["(0,3)"])))
  count_df["freq:(1,0)"] <-
    as.numeric(unlist(count_df["(1,0)"] / (count_df["(1,0)"] + count_df["(1,3)"])))
  count_df["freq:(1,3)"] <-
    as.numeric(unlist(count_df["(1,3)"] / (count_df["(1,0)"] + count_df["(1,3)"])))
  #print(count_df)############################################
  # wilcoxon test
  result_str = NA
  #if (sum(count_df[, "freq:1"] + sum(count_df[, "freq:2"])) == 0) {
  if(!is.nan(count_df[1,"freq:(0,0)"])){
    result = wtest(count_df[,"freq:(0,0)"])
    if(!is.na(result["pvalue"])&result["pvalue"]<0.01){
      flag = 3 
    }
    result_str_0_0 <- 
      paste("(0,0):", result_generating(result))
  }else{
    result_str_0_0 <-
      paste("")
  }
  if(!is.nan(count_df[1,"freq:(0,3)"])){
    result = wtest(count_df[,"freq:(0,3)"])
    if(!is.na(result["pvalue"])&result["pvalue"]<0.01){
      flag = 3
    }
    result_str_0_3 <-
      paste("(0,3):", result_generating(result))
  }else{
    result_str_0_3 <-
      paste("")
  }
  if(!is.nan(count_df[1,"freq:(1,0)"])){
  result = wtest(count_df[,"freq:(1,0)"])
  if(!is.na(result["pvalue"])&result["pvalue"]<0.01){
    flag = 3
  }
    result_str_1_0 <-
      paste("(1,0):", result_generating(result))
  }else{
    result_str_1_0 <-
      paste("")
  }
  if(!is.nan(count_df[1,"freq:(1,3)"])){
    result = wtest(count_df[,"freq:(1,3)"])
    if(!is.na(result["pvalue"])&result["pvalue"]<0.01){
      flag = 3
    }
    result_str_1_3 <-
      paste("(1,3):", result_generating(result))  
  }else{
    result_str_1_3 <-
      paste("")
  }

    result_str_test_suite_size<-
      paste("Total_test_cases:",file_test_suite_size)
    if(flag == 4){
      Pass[col] = Pass[col]+1
      #Pass[col] <- Pass[col]+1
      print("PASS:")
      print(file_test_suite_size)
      print(Pass[col])
      total_test_suite_size[col]<-total_test_suite_size[col]+file_test_suite_size
      total_pass_case[col] = (total_pass_case[col] + file_test_suite_size)
      result_str_category <-
        paste("Category:Passed")
    }else if(flag == 3){
      O3[col] = O3[col]+1
      print("O3:")
      print(file_test_suite_size)
      print(O3[col])
      total_test_suite_size[col]<-total_test_suite_size[col]+file_test_suite_size
      total_O3_case[col] = (total_O3_case[col] + file_test_suite_size)
      result_str_category <-
        paste("Category:O3")
    }
    
    result_str = paste(result_str_0_0,
                       result_str_0_3,
                       result_str_1_0,
                       result_str_1_3,
                       result_str_test_suite_size,
                       result_str_category,
                       sep = "\n")
    
  }
  #else{
  #  result_str_test_suite_size<-
  #    paste("Total_test_cases:",file_test_suite_size)
  #  result_str =paste("Failed",result_str_test_suite_size, sep="\n")
    
  #}
  test_result_df[row, col] = result_str
  
}

# output
test_result_df["O1","C1"] = O1["C1"]/10
if(O1["C1"]==0){
  test_result_df["O1_AVG","C1"] = 0
}else{
  test_result_df["O1_AVG","C1"] = total_O1_case["C1"]/O1["C1"]
}

test_result_df["O1","C2"] = O1["C2"]/10
if(O1["C2"]==0){
  test_result_df["O1_AVG","C2"] = 0
}else{
  test_result_df["O1_AVG","C2"] = total_O1_case["C2"]/O1["C2"]
}

test_result_df["O1","C3"] = O1["C3"]/10
if(O1["C3"]==0){
  test_result_df["O1_AVG","C3"] = 0
}else{
  test_result_df["O1_AVG","C3"] = total_O1_case["C3"]/O1["C3"]
}

test_result_df["O3","C1"] = O3["C1"]/10
if(O3["C1"]==0){
  test_result_df["O3_AVG","C1"] = 0
}else{
  test_result_df["O3_AVG","C1"] = total_O3_case["C1"]/O3["C1"]
}

test_result_df["O3","C2"] = O3["C2"]/10
if(O3["C2"]==0){
  test_result_df["O3_AVG","C2"] = 0
}else{
  test_result_df["O3_AVG","C2"] = total_O3_case["C2"]/O3["C2"]
}

test_result_df["O3","C3"] = O3["C3"]/10
if(O3["C3"]==0){
  test_result_df["O3_AVG","C3"] = 0
}else{
  test_result_df["O3_AVG","C3"] = total_O3_case["C3"]/O3["C3"]
}

test_result_df["Pass","C1"] = Pass["C1"]/10
if(Pass["C1"]==0){
  test_result_df["Pass_AVG","C1"] = 0
}else{
  test_result_df["Pass_AVG","C1"] = total_pass_case["C1"]/Pass["C1"]
}

test_result_df["Pass","C2"] = Pass["C2"]/10
if(Pass["C2"]==0){
  test_result_df["Pass_AVG","C2"] = 0
}else{
  test_result_df["Pass_AVG","C2"] = total_pass_case["C2"]/Pass["C2"]
}

test_result_df["Pass","C3"] = Pass["C3"]/10
if(Pass["C3"]==0){
  test_result_df["Pass_AVG","C3"] = 0
}else{
  test_result_df["Pass_AVG","C3"] = total_pass_case["C3"]/Pass["C3"]
}
test_result_df["Total_Test_Cases","C1"] = total_test_suite_size["C1"]/10
test_result_df["Total_Test_Cases","C2"] = total_test_suite_size["C2"]/10
test_result_df["Total_Test_Cases","C3"] = total_test_suite_size["C3"]/10
#test_result_df["Avg_test_suite_size","C1"]=total_test_cases["C1"] / total_test_suite_count["C1"]
#test_result_df["Avg_test_suite_size","C2"]=total_test_cases["C2"] / total_test_suite_count["C2"]
#test_result_df["Avg_test_suite_size","C3"]=total_test_cases["C3"] / total_test_suite_count["C3"]
print(test_result_df)
write.csv(test_result_df, file.path(output_dir, "test_result.csv"))


############### functions ###################
wtest <- function(data) {
  result <- c(0, 0, 0, 0)
  names(result) = c("pvalue", "r", "coi_l", "coi_r")
  test_result <-
    wilcox.test(data,
                mu = 0.5,
                conf.int = TRUE,
                conf.level = 0.99)
  r <- wilcoxonOneSampleR(data, mu = 0.5)
  result["pvalue"] = NA
  result["r"] = NA
  result["coi_l"] = test_result$conf.int[1]
  result["coi_r"] = test_result$conf.int[2]
  
  # generate output format
  if (!is.na(r)) {
    result["r"] = round(r, 3)
  }
  if (!is.na(test_result$conf.int[1])) {
    result["coi_l"] = round(test_result$conf.int[1], 3)
  }
  if (!is.na(test_result$conf.int[2])) {
    result["coi_r"] = round(test_result$conf.int[2], 3)
  }
  pvalue_threshhold = 1e-4
  if (!is.na(test_result$p.value)) {#not NA
    if (test_result$p.value < pvalue_threshhold) {
      result["pvalue"] = 0#<1e-4
     # result_str = paste("pvalue",
     #                    result["pvalue"],
      #                   "r=",
       #                  result["r"],
        #                 "CoI=(",
         #                result["coi_l"],
          #               ",",
           #              result["coi_r"],
            #             ")")
      return (result)
    }
    else{
      result["pvalue"] = signif(test_result$p.value, 5)
    }
  }
 # result_str = paste("pvalue=",
 #                    result["pvalue"],
#                     "r=",
 #                    result["r"],
  #                   "CoI=(",
   #                  result["coi_l"],
  #                   ",",
   #                  result["coi_r"],
    #                 ")")
  return (result)
}

result_generating <- function(result){
  if (result["pvalue"]==0){
    result["pvalue"] = paste("<",1e-4)
  }
    result_str = paste("pvalue=",
                       result["pvalue"],
                       "r=",
                       result["r"],
                       "CoI=(",
                       result["coi_l"],
                       ",",
                       result["coi_r"],
                       ")")
   return (result_str)
}

parse_fpath <- function(fpath) {
  fname = tail(unlist(strsplit(fpath, "/")), 1)
  c_i = unlist(gregexpr(pattern = "C", fname))
  dot_i = unlist(gregexpr(pattern = "\\.", fname))
  row_name = substr(fname, 1, c_i - 1)
  col_name = substr(fname, c_i, dot_i - 1)
  return (c(row_name, col_name))
}
